//
//  ViewController.swift
//  SatyuktTask2
//
//  Created by Pushpam on 01/09/21.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var imgView:UIImageView!
    
    var picker = UIImagePickerController()

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    func showAlert(msg:String) {
        let alertVC = UIAlertController.init(title: "Alert", message: msg, preferredStyle: .alert)
        let ok = UIAlertAction.init(title: "OK", style: .default) { (alert) in
        }
        alertVC.addAction(ok)
        self.present(alertVC, animated: true, completion: nil)
    }
    
    @IBAction func startCameraBtn(_ sender: Any) {
        self.showOptionAlert()
    }
    
    @IBAction func viewImageBtnAction(_ sender: Any) {
        let list = self.getAllImageList()
        let gridVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(identifier: "GridView") as! GridView
        gridVC.imageUrls = list
        self.navigationController?.pushViewController(gridVC, animated: true)
    }
    
    @IBAction func saveImage(_ sender: Any) {
        if let image = imgView.image {
            self.saveImageInDocumentDirectory(image: image)
            self.showAlert(msg:"Image saved sucessfully")
        }
    }
    
    func showOptionAlert() {
        let alert = UIAlertController(title: "Choose Image", message: nil, preferredStyle: .actionSheet)

        let cameraAction = UIAlertAction(title: "Camera", style: .default){
            UIAlertAction in
            self.openCamera()
        }
        let galleryAction = UIAlertAction(title: "Gallery", style: .default){
            UIAlertAction in
            self.openGallery()
        }
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel){
            UIAlertAction in
        }

        // Add the actions
        picker.delegate = self
        picker.allowsEditing = true
        alert.addAction(cameraAction)
        alert.addAction(galleryAction)
        alert.addAction(cancelAction)
        self.present(alert, animated: true, completion: nil)
    }
    
    func openCamera(){
        if(UIImagePickerController .isSourceTypeAvailable(.camera)){
            picker.sourceType = .camera
            self.present(picker, animated: true, completion: nil)
        }
        else {
            self.showAlert(msg: "You don't have camera")
        }
    }
    
    func openGallery(){
        picker.sourceType = .photoLibrary
        self.present(picker, animated: true, completion: nil)
    }
}

extension ViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    ///Delegate method
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        picker.dismiss(animated: true, completion: nil)
        let image = info[.editedImage] as? UIImage
        self.imgView.image = image
    }
}

extension ViewController {
    func saveImageInDocumentDirectory(image:UIImage) {
        
        let dataPath = self.getDirectoryPath()

        //Check is folder available or not, if not create
        if !FileManager.default.fileExists(atPath: dataPath.path) {
            do {
                try FileManager.default.createDirectory(atPath: dataPath.path, withIntermediateDirectories: true, attributes: nil) //Create folder if not
            } catch {
                print("error:", error)
            }
        }
        
        // create the destination file url to save your image
        let fileURL = URL(fileURLWithPath:dataPath.path).appendingPathComponent("\(Date().timeIntervalSince1970).jpg")//Your image name
        print(fileURL)
        // get your UIImage jpeg data representation
        let data = image.jpegData(compressionQuality: 1.0)//Set image quality here
        do {
            // writes the image data to disk
            try data?.write(to: fileURL, options: .atomic)
        } catch {
            print("error:", error)
        }
    }
    
    func getAllImageList() -> [String] {
       
        let dataPath = self.getDirectoryPath()
       
        //Check is folder available or not, if not create
        if !FileManager.default.fileExists(atPath: dataPath.path) {
            return []
        }
        
        var finalItems = [String]()
        let theItems = try! FileManager.default.contentsOfDirectory(atPath: dataPath.path)
        
        for item in theItems {
            let finalDataPath = dataPath.appendingPathComponent(item)
            finalItems.append(finalDataPath.path)
        }
        
        return finalItems
    }
    
    func getDirectoryPath()-> URL {
        let paths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let documentsDirectory = paths[0]
        let dataPath = URL(fileURLWithPath: documentsDirectory).appendingPathComponent("ImagesFolder")
        print(dataPath)
        return dataPath
    }
}
